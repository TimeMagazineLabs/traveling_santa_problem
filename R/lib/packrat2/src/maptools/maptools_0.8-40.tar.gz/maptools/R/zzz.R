#.First.lib <- function(lib, pkg) {
#          library.dynam("maptools", pkg, lib)
#}
## .noGenerics <- TRUE
#maptools()
#
#".onLoad" <- function(lib, pkg) require(methods)
#
